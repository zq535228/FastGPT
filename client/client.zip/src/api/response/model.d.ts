import { ModelListItemType } from '@/types/model';

export type ModelListResponse = {
  myModels: ModelListItemType[];
  myCollectionModels: ModelListItemType[];
};
