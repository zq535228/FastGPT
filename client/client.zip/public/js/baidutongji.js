var _hmt = _hmt || [];

(function () {
  const hm = document.createElement('script');
  hm.src = 'https://hm.baidu.com/hm.js?a5357e9dab086658bac0b6faf148882e';
  const s = document.getElementsByTagName('script')[0];
  s.parentNode.insertBefore(hm, s);
})();
